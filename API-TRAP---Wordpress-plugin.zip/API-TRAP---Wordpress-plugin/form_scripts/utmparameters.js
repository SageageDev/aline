(function () {
  console.log('Gravity API Trap: Script loaded successfully');

  function getParam(name) {
    const url = new URL(window.location.href);
    return (url.searchParams.get(name) || '').trim();
  }

  function deriveMarketSource() {
    const utm_source   = getParam('utm_source').toLowerCase();
    const utm_medium   = getParam('utm_medium').toLowerCase();
    const utm_campaign = getParam('utm_campaign').toLowerCase();

    const gclid      = getParam('gclid');
    const fbclid     = getParam('fbclid');
    const gad        = getParam('gad');
    const gad_source = getParam('gad_source').toLowerCase();

    const hasGoogleClick = !!(gclid || gad || gad_source);
    const hasMetaClick   = !!fbclid;

    // Direct: GA4's (direct)/(none) or explicit medium value
    if (utm_source === '(direct)' || utm_medium === '(none)' ||
        utm_medium === 'none'     || utm_medium === 'direct') {
      return 'WEB - Direct Web Traffic';
    }

    // Medium-based routing
    if (utm_medium === 'referral') return 'WEB - Referral Web Traffic';
    if (utm_medium === 'organic')  return 'WEB - Organic Search';
    if (utm_medium === 'social')   return 'Web - Organic Social';
    if (['email','newsletter','e-mail'].includes(utm_medium)) return 'Email';

    const isPaidSocial =
      ['paidsocial','paid_social','paid-social','paid social'].includes(utm_medium) ||
      (utm_medium.includes('paid') && utm_medium.includes('social'));
    const isPaidSearch =
      ['cpc','ppc','sem','paid_search','paidsearch','paid-search'].includes(utm_medium) ||
      (utm_medium.includes('paid') && !utm_medium.includes('social'));

    if (isPaidSocial) return 'Web - Paid Social';
    if (isPaidSearch) return 'Web - Paid Search';

    // Cross-network: Performance Max and multi-channel campaigns
    if (utm_medium === 'cross-network' || utm_medium === 'cross_network' ||
        utm_campaign.includes('pmax')   || utm_campaign.includes('performance_max') ||
        utm_campaign.includes('performance max')) {
      return 'WEB - Cross-network Web Traffic';
    }

    // Click-ID fallbacks when utm_medium is absent (auto-tagging)
    if (hasGoogleClick) return 'Web - Paid Search';
    if (hasMetaClick)   return 'Web - Paid Social';

    // Has UTM data but no matching medium
    if (utm_source || utm_medium || utm_campaign) return 'WEB - Referral Web Traffic';

    return 'WEB - Company Website';
  }

  function setInputValue(input, value) {
    if (!input || value === undefined || value === null) return;
    // Only set non-empty values to avoid interfering with required field validation
    if (value !== '') {
      console.log('Gravity API Trap: Setting input', input.id || input.name, 'to value:', value);
      input.value = value;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  // Scan a form for a dropdown whose options include employment-related values,
  // so no form ID needs to be hardcoded.
  function findEmploymentDropdown(formEl) {
    const selects = formEl.querySelectorAll('select');
    for (const sel of selects) {
      for (const opt of sel.options) {
        const text = (opt.text || '').toLowerCase();
        const val  = (opt.value || '').toLowerCase();
        if (text.includes('employ') || text.includes('job') ||
            val.includes('employ')  || val.includes('job')) {
          return sel;
        }
      }
    }
    return null;
  }

  function findNoTriggerInput(formEl) {
    const candidates = formEl.querySelectorAll('input[type="text"], input[type="hidden"]');
    for (const inp of candidates) {
      const field = inp.closest('.gfield');
      const label = field ? (field.querySelector('label.gfield_label')?.textContent || '').toLowerCase() : '';
      const name  = (inp.name || '').toLowerCase();
      const id    = (inp.id || '').toLowerCase();

      if (label.includes('notrigger') || label.includes('no trigger') || label.includes('suppress') || label.includes('trigger') ||
          name.includes('notrigger')  || name.includes('trigger')  || id.includes('notrigger')) {
        return inp;
      }
    }
    return null;
  }

  function applyNoTriggerRule(formEl) {
    const dropdown = findEmploymentDropdown(formEl);
    if (!dropdown) return;

    const noTrigger = findNoTriggerInput(formEl);
    if (!noTrigger) return;

    const selectedValue = (dropdown.value || '').toLowerCase().trim();
    const selectedText  = (dropdown.options[dropdown.selectedIndex]?.text || '').toLowerCase().trim();

    const isEmployment =
      selectedValue === 'employment' || selectedValue.includes('employ') || selectedValue.includes('job') ||
      selectedText  === 'employment' || selectedText.includes('employ')  || selectedText.includes('job');

    if (isEmployment) {
      console.log('Gravity API Trap: Employment selected — setting NoTrigger to True');
      noTrigger.value = 'True';
      noTrigger.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      noTrigger.value = '';
      noTrigger.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  // Bind all employment-suppression listeners for a form.
  // Runs independently of UTM data so the rule always applies.
  function bindNoTriggerListeners(form) {
    const dropdown = findEmploymentDropdown(form);
    if (!dropdown) return;

    const noTrigger = findNoTriggerInput(form);
    if (!noTrigger) return;

    // Initialize field to empty on setup
    noTrigger.value = '';
    console.log('Gravity API Trap: NoTrigger initialized for', dropdown.id || dropdown.name);

    // Apply rule now, then again after short delays for late-rendering fields
    applyNoTriggerRule(form);
    setTimeout(function () { applyNoTriggerRule(form); }, 500);
    setTimeout(function () { applyNoTriggerRule(form); }, 2000);

    // Only attach listeners once per dropdown
    if (dropdown.dataset.mwNoTriggerBound) return;

    // Native change listener
    dropdown.addEventListener('change', function () {
      applyNoTriggerRule(form);
    });

    // jQuery listener — Gravity Forms triggers jQuery change events internally
    if (typeof jQuery !== 'undefined') {
      jQuery(dropdown).on('change', function () {
        applyNoTriggerRule(form);
      });
    }

    // Watch for programmatic value changes on the dropdown (e.g. conditional logic)
    const observer = new MutationObserver(function () {
      applyNoTriggerRule(form);
    });
    observer.observe(dropdown, { attributes: true });

    dropdown.dataset.mwNoTriggerBound = '1';
    console.log('Gravity API Trap: NoTrigger listeners bound for', dropdown.id || dropdown.name);
  }

  function setUTMValues(form) {
    const utmSource   = getParam('utm_source');
    const utmMedium   = getParam('utm_medium');
    const utmCampaign = getParam('utm_campaign');
    const utmId       = getParam('utm_id');
    const gclid       = getParam('gclid');
    const fbclid      = getParam('fbclid');
    const gad         = getParam('gad');
    const gadSource   = getParam('gad_source');
    const display     = getParam('display');

    const hasTrackingData = utmSource || utmMedium || utmCampaign || utmId || gclid || fbclid || gad || gadSource || display;
    if (!hasTrackingData) return;

    try {
      const derived = deriveMarketSource();
      console.log('Gravity API Trap: Derived MarketSource:', derived || '(none)');

      const labels = form.querySelectorAll('label.gfield_label');
      labels.forEach(function (label) {
        try {
          const inputId = label.getAttribute('for');
          if (!inputId) return;

          const input = form.querySelector('#' + CSS.escape(inputId));
          if (!input) return;

          const key = label.textContent.trim().toLowerCase();

          if      (key === 'utmsource')                           setInputValue(input, utmSource);
          else if (key === 'utmmedium' || key === 'utmedium')    setInputValue(input, utmMedium);
          else if (key === 'utmcampaign')                         setInputValue(input, utmCampaign);
          else if (key === 'utmid')                               setInputValue(input, utmId);
          else if (key === 'gclid')                               setInputValue(input, gclid);
          else if (key === 'fbclid')                              setInputValue(input, fbclid);
          else if (key === 'gad')                                 setInputValue(input, gad);
          else if (key === 'gad_source')                          setInputValue(input, gadSource);
          else if (key === 'display')                             setInputValue(input, display);
          else if (key === 'marketsource' || key === 'market source') setInputValue(input, derived);
        } catch (e) {
          console.warn('Error setting field value:', e);
        }
      });

      // Also try CSS class as a secondary targeting method
      if (derived) {
        const msField = form.querySelector('.mw-marketsource input');
        if (msField) setInputValue(msField, derived);
      }
    } catch (e) {
      console.warn('Error processing form UTM values:', e);
    }
  }

  function processAllForms() {
    console.log('Gravity API Trap: processAllForms called');
    const forms = document.querySelectorAll('.gform_wrapper form');
    console.log('Gravity API Trap: Found forms:', forms.length);

    forms.forEach(function (form, index) {
      console.log('Gravity API Trap: Processing form', index + 1);
      bindNoTriggerListeners(form); // always runs, regardless of UTM data
      setUTMValues(form);           // only runs when tracking params are present
    });
  }

  // Gravity Forms AJAX events
  document.addEventListener('gform_post_render', function () {
    console.log('Gravity API Trap: gform_post_render fired');
    setTimeout(processAllForms, 100);
  });

  document.addEventListener('gform_post_conditional_logic', function () {
    console.log('Gravity API Trap: gform_post_conditional_logic fired');
    setTimeout(processAllForms, 100);
  });

  // Fallback: poll until forms appear, then stop
  let checkInterval = setInterval(function () {
    if (document.querySelectorAll('.gform_wrapper form').length > 0) {
      console.log('Gravity API Trap: Found forms via interval check');
      processAllForms();
      clearInterval(checkInterval);
    }
  }, 1000);

  setTimeout(function () {
    clearInterval(checkInterval);
  }, 10000);

})();
